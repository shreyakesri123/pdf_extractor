import { useState } from 'react';
import { PdfExtractionResponse, ExtractedTableData } from '@shared/schema';
import { downloadFile, createExcelDownloadUrl } from '@/lib/pdf-utils';
import { useToast } from '@/hooks/use-toast';

export type ExtractionStep = "upload" | "process" | "preview" | "download";

export function usePdfExtraction() {
  const [isUploading, setIsUploading] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [extractedDocument, setExtractedDocument] = useState<PdfExtractionResponse | null>(null);
  const [selectedTableIndex, setSelectedTableIndex] = useState(0);
  const [currentStep, setCurrentStep] = useState<ExtractionStep>("upload");
  const { toast } = useToast();

  // Extract tables from PDF
  const handleFileUpload = async (uploadedFile: File) => {
    setIsUploading(true);
    setCurrentStep("process");
    
    try {
      // Create form data
      const formData = new FormData();
      formData.append('pdf', uploadedFile);
      
      // Send request to extract tables API
      const response = await fetch('/api/extract-tables', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }
      
      const result: PdfExtractionResponse = await response.json();
      
      if (result.tables.length === 0) {
        toast({
          title: "No tables found",
          description: "We couldn't detect any tables in the uploaded PDF.",
          variant: "destructive",
        });
        setCurrentStep("upload");
      } else {
        setExtractedDocument(result);
        setSelectedTableIndex(result.tables[0].tableIndex);
        setCurrentStep("preview");
        toast({
          title: "Tables extracted successfully",
          description: `Found ${result.tables.length} table${result.tables.length > 1 ? 's' : ''} in the document.`,
        });
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      
      toast({
        title: "Extraction failed",
        description: error instanceof Error ? error.message : "Failed to extract tables from PDF",
        variant: "destructive",
      });
      
      setCurrentStep("upload");
    } finally {
      setIsUploading(false);
    }
  };

  // Download table as Excel
  const handleDownload = async (consolidated: boolean = false) => {
    if (!extractedDocument) return;
    
    setIsDownloading(true);
    setCurrentStep("download");
    
    try {
      const tableId = consolidated ? undefined : extractedDocument.tables.find(
        t => t.tableIndex === selectedTableIndex
      )?.tableIndex;
      
      const url = createExcelDownloadUrl(extractedDocument.documentId, tableId);
      
      // Generate filename
      const baseFilename = extractedDocument.filename.replace(/\.pdf$/i, '');
      const filename = consolidated 
        ? `${baseFilename}_all_tables.xlsx` 
        : `${baseFilename}_table_${selectedTableIndex + 1}.xlsx`;
      
      await downloadFile(url, filename);
      
      toast({
        title: "Download complete",
        description: `The Excel file has been downloaded successfully.`,
      });
    } catch (error) {
      console.error('Error downloading:', error);
      
      toast({
        title: "Download failed",
        description: error instanceof Error ? error.message : "Failed to download Excel file",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  // Reset to upload stage
  const resetExtraction = () => {
    setExtractedDocument(null);
    setSelectedTableIndex(0);
    setCurrentStep("upload");
  };

  return {
    isUploading,
    isDownloading,
    extractedDocument,
    selectedTableIndex,
    setSelectedTableIndex,
    currentStep,
    handleFileUpload,
    handleDownload,
    resetExtraction,
  };
}