import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { TableData } from '@shared/schema';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface TablePreviewProps {
  tables: Array<{
    tableIndex: number;
    data: TableData;
  }>;
  selectedTableIndex: number;
  onSelectTable: (index: number) => void;
}

export function TablePreview({
  tables,
  selectedTableIndex,
  onSelectTable
}: TablePreviewProps) {
  const [visibleRows, setVisibleRows] = useState(15);
  
  // Find the current table by index
  const currentTable = tables.find(t => t.tableIndex === selectedTableIndex);
  
  if (!tables.length || !currentTable) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Table Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-muted-foreground">No tables found in the document</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Get all table indexes for navigation
  const tableIndexes = tables.map(t => t.tableIndex).sort((a, b) => a - b);
  
  // Get current position in tables array
  const currentPosition = tableIndexes.indexOf(selectedTableIndex);
  
  // Navigate to previous table
  const navigatePrevious = () => {
    if (currentPosition > 0) {
      onSelectTable(tableIndexes[currentPosition - 1]);
    }
  };
  
  // Navigate to next table
  const navigateNext = () => {
    if (currentPosition < tableIndexes.length - 1) {
      onSelectTable(tableIndexes[currentPosition + 1]);
    }
  };
  
  // Get table data
  const { headers, rows } = currentTable.data;
  
  // Show 15 rows by default, but show all if scrolling to the bottom
  const displayRows = rows.slice(0, visibleRows);
  
  // Add more rows when scrolling
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const element = e.currentTarget;
    const isNearEnd = element.scrollHeight - element.scrollTop - element.clientHeight < 100;
    
    if (isNearEnd && visibleRows < rows.length) {
      setVisibleRows(prev => Math.min(prev + 10, rows.length));
    }
  };
  
  // Reset visible rows when table changes
  useEffect(() => {
    setVisibleRows(15);
  }, [selectedTableIndex]);
  
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="py-4 px-6">
        <div className="flex items-center justify-between">
          <CardTitle>Table {selectedTableIndex + 1}</CardTitle>
          <div className="flex items-center gap-2">
            <button 
              onClick={navigatePrevious}
              disabled={currentPosition === 0}
              className={`p-2 rounded-full hover:bg-muted ${currentPosition === 0 ? 'text-muted-foreground' : ''}`}
              aria-label="Previous table"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <span className="text-sm text-muted-foreground">{currentPosition + 1} of {tableIndexes.length}</span>
            <button 
              onClick={navigateNext}
              disabled={currentPosition === tableIndexes.length - 1}
              className={`p-2 rounded-full hover:bg-muted ${currentPosition === tableIndexes.length - 1 ? 'text-muted-foreground' : ''}`}
              aria-label="Next table"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 p-0 h-full overflow-hidden">
        <Tabs defaultValue="preview" className="h-full flex flex-col">
          <div className="px-6 border-b">
            <TabsList>
              <TabsTrigger value="preview">Preview</TabsTrigger>
              <TabsTrigger value="data">Raw Data</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="preview" className="flex-1 h-0 p-0 m-0 data-[state=active]:flex flex-col">
            <ScrollArea className="h-full" onScroll={handleScroll}>
              <div className="p-4">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {headers.map((header, i) => (
                          <TableHead key={i} className="font-semibold">
                            {header}
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {displayRows.map((row, rowIdx) => (
                        <TableRow key={rowIdx}>
                          {row.map((cell, cellIdx) => (
                            <TableCell 
                              key={cellIdx}
                              rowSpan={cell.rowSpan}
                              colSpan={cell.colSpan}
                            >
                              {cell.text}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {visibleRows < rows.length && (
                  <div className="text-center py-4 text-sm text-muted-foreground">
                    Showing {visibleRows} of {rows.length} rows. Scroll to load more.
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="data" className="flex-1 h-0 p-0 m-0 data-[state=active]:block">
            <ScrollArea className="h-full">
              <div className="p-6">
                <pre className="bg-muted p-4 rounded-md overflow-auto text-sm">
                  {JSON.stringify(currentTable.data, null, 2)}
                </pre>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}