import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PdfExtractionResponse } from '@shared/schema';
import { FileIcon, FileText, LayoutGrid } from 'lucide-react';
import { formatDate, formatFileSize } from '@/lib/pdf-utils';

interface PdfPreviewProps {
  document: PdfExtractionResponse;
  onViewPdf?: () => void;
}

export function PdfPreview({ document, onViewPdf }: PdfPreviewProps) {
  const [showPdf, setShowPdf] = useState(false);
  
  // Calculate the total number of tables extracted
  const tableCount = document.tables.length;
  
  // Create a URL for PDF preview (if in browser environment)
  const handleViewPdf = () => {
    if (onViewPdf) {
      onViewPdf();
    } else {
      setShowPdf(true);
    }
  };
  
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle>Document Preview</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        {/* Document metadata */}
        <div className="p-4 bg-muted rounded-lg mb-4">
          <div className="flex items-start gap-3">
            <div className="mt-1">
              <FileIcon className="h-8 w-8 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium">{document.filename}</h3>
              <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1 text-sm text-muted-foreground">
                <span>{formatFileSize(document.filesize)}</span>
                <span>Uploaded: {formatDate(document.uploadDate)}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Extraction summary */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-primary/10 rounded-lg p-4 flex flex-col items-center justify-center">
            <LayoutGrid className="h-8 w-8 text-primary mb-2" />
            <div className="text-2xl font-bold">{tableCount}</div>
            <div className="text-sm text-muted-foreground">Tables Extracted</div>
          </div>
          <div className="bg-primary/10 rounded-lg p-4 flex flex-col items-center justify-center">
            <FileText className="h-8 w-8 text-primary mb-2" />
            <div className="text-2xl font-bold">
              {document.tables.reduce((total, table) => total + table.data.rows.length, 0)}
            </div>
            <div className="text-sm text-muted-foreground">Total Rows</div>
          </div>
        </div>
        
        {/* Table list preview */}
        <div className="mb-4 flex-1">
          <h3 className="text-sm font-medium mb-2">Extracted Tables</h3>
          <div className="space-y-2 overflow-auto max-h-[200px]">
            {document.tables.map((table) => (
              <div 
                key={table.tableIndex}
                className="p-3 border rounded-md text-sm hover:bg-muted/50 transition-colors"
              >
                <div className="font-medium">Table {table.tableIndex + 1}: {table.info.type}</div>
                <div className="flex flex-wrap gap-x-3 mt-1 text-muted-foreground">
                  <span>Page {table.info.pageNumber}</span>
                  <span>{table.info.rowCount} rows × {table.info.columnCount} columns</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* View PDF button */}
        <Button 
          variant="outline" 
          onClick={handleViewPdf}
          className="w-full"
        >
          <FileText className="mr-2 h-4 w-4" />
          View Original PDF
        </Button>
        
        {/* PDF iframe (hidden by default) */}
        {showPdf && (
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-5xl max-h-[90vh] flex flex-col">
              <CardHeader className="py-3">
                <div className="flex items-center justify-between">
                  <CardTitle>PDF Preview: {document.filename}</CardTitle>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowPdf(false)}
                  >
                    Close
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="flex-1 p-0 min-h-0">
                <div className="h-[70vh] w-full bg-muted flex items-center justify-center">
                  <p className="text-muted-foreground">PDF preview not available in this view.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </CardContent>
    </Card>
  );
}