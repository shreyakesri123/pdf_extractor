import { Check } from "lucide-react";

export type ExtractionStep = "upload" | "process" | "preview" | "download";

interface ProgressTrackerProps {
  currentStep: ExtractionStep;
}

export function ProgressTracker({ currentStep }: ProgressTrackerProps) {
  const steps: Array<{ id: ExtractionStep; label: string }> = [
    { id: "upload", label: "Upload" },
    { id: "process", label: "Process" },
    { id: "preview", label: "Preview" },
    { id: "download", label: "Download" },
  ];

  // Get the index of the current step
  const currentStepIndex = steps.findIndex((step) => step.id === currentStep);

  return (
    <div className="py-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-slate-700">Extraction Process</h2>
      </div>
      <nav aria-label="Progress">
        <ol role="list" className="flex items-center">
          {steps.map((step, index) => {
            const isCompleted = index < currentStepIndex;
            const isCurrent = index === currentStepIndex;
            const isUpcoming = index > currentStepIndex;
            
            return (
              <li
                key={step.id}
                className={`relative ${
                  index !== steps.length - 1 ? "pr-8 sm:pr-20" : ""
                }`}
              >
                {index !== steps.length - 1 && (
                  <div className="absolute inset-0 flex items-center" aria-hidden="true">
                    <div
                      className={`h-0.5 w-full ${
                        isCompleted || isCurrent
                          ? "bg-primary-600"
                          : "bg-slate-200"
                      }`}
                    ></div>
                  </div>
                )}
                <div
                  className={`relative flex h-8 w-8 items-center justify-center rounded-full ${
                    isCompleted || isCurrent
                      ? "bg-primary-600 hover:bg-primary-800"
                      : isUpcoming
                      ? "border-2 border-primary-600 bg-white"
                      : "bg-slate-200"
                  }`}
                >
                  {isCompleted ? (
                    <>
                      <Check className="h-5 w-5 text-white" />
                      <span className="sr-only">{step.label}</span>
                    </>
                  ) : isCurrent ? (
                    <>
                      <span className="h-2.5 w-2.5 rounded-full bg-white" aria-hidden="true"></span>
                      <span className="sr-only">{step.label}</span>
                    </>
                  ) : isUpcoming ? (
                    <>
                      <span
                        className="h-2.5 w-2.5 rounded-full bg-primary-600"
                        aria-hidden="true"
                      ></span>
                      <span className="sr-only">{step.label}</span>
                    </>
                  ) : null}
                </div>
                <div
                  className={`text-xs font-medium mt-2 ${
                    isCurrent ? "text-primary-700" : "text-slate-600"
                  }`}
                >
                  {step.label}
                </div>
              </li>
            );
          })}
        </ol>
      </nav>
    </div>
  );
}
