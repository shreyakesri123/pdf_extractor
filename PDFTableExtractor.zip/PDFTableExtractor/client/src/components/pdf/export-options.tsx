import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PdfExtractionResponse } from '@shared/schema';
import { BadgeCheck, Download, FileSpreadsheet, Table2 } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface ExportOptionsProps {
  document: PdfExtractionResponse;
  onDownload: (consolidated: boolean) => void;
  isDownloading: boolean;
  accuracy?: number;
}

export function ExportOptions({
  document,
  onDownload,
  isDownloading,
  accuracy = 90
}: ExportOptionsProps) {
  // Get count of tables and total rows
  const tableCount = document.tables.length;
  const totalRows = document.tables.reduce((total, table) => total + table.data.rows.length, 0);
  
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle>Export Options</CardTitle>
        <CardDescription>Download the extracted data</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <Tabs defaultValue="individual" className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="individual">Individual Tables</TabsTrigger>
            <TabsTrigger value="consolidated">Consolidated</TabsTrigger>
          </TabsList>
          
          <TabsContent value="individual" className="mt-4 flex-1 flex flex-col">
            <div className="mb-4">
              <p className="text-sm text-muted-foreground">
                Export each table individually. Each table will be exported as a separate worksheet.
              </p>
            </div>
            
            <div className="space-y-3 mb-6 flex-1">
              {document.tables.map((table) => (
                <div 
                  key={table.tableIndex}
                  className="p-3 border rounded-md flex items-start justify-between"
                >
                  <div>
                    <div className="font-medium">Table {table.tableIndex + 1}: {table.info.type}</div>
                    <div className="text-sm text-muted-foreground">
                      {table.data.rows.length} rows × {table.data.headers.length} columns
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => onDownload(false)}
                    disabled={isDownloading}
                  >
                    <FileSpreadsheet className="h-4 w-4 mr-1" />
                    <span className="sr-only md:not-sr-only md:inline">Export</span>
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="consolidated" className="mt-4 flex-1 flex flex-col">
            <div className="mb-4">
              <p className="text-sm text-muted-foreground">
                Export all tables in a single Excel file with multiple worksheets and a summary sheet.
              </p>
            </div>
            
            <div className="p-5 bg-muted rounded-lg mb-6 flex-1">
              <div className="flex items-center justify-center flex-col text-center py-6">
                <div className="bg-primary/10 p-3 rounded-full mb-3">
                  <Table2 className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-1">{tableCount} Tables</h3>
                <p className="text-muted-foreground">{totalRows} total rows of data</p>
                
                <div className="w-full mt-6">
                  <div className="flex justify-between items-center mb-1">
                    <div className="text-sm flex items-center">
                      <BadgeCheck className="h-4 w-4 text-primary mr-1" />
                      Data Quality
                    </div>
                    <span className="text-sm font-medium">{accuracy}%</span>
                  </div>
                  <Progress value={accuracy} className="h-2" />
                </div>
              </div>
            </div>
            
            <Button 
              onClick={() => onDownload(true)}
              disabled={isDownloading}
              className="w-full"
            >
              {isDownloading ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                  Downloading...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Download All Tables
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}