import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TableInfo } from "@shared/schema";
import { Info } from "lucide-react";

interface TableInfoCardProps {
  info: TableInfo;
}

export function TableInfoCard({ info }: TableInfoCardProps) {
  return (
    <Card className="overflow-hidden border border-slate-200 mt-4">
      <CardHeader className="px-4 py-5 sm:px-6 bg-slate-50 flex flex-row items-center space-y-0">
        <Info className="h-5 w-5 mr-2 text-primary-500" />
        <CardTitle className="text-lg leading-6 font-medium text-slate-900">
          Table Information
        </CardTitle>
      </CardHeader>
      <CardContent className="border-t border-slate-200 px-4 py-5 sm:p-6">
        <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-slate-500">Table Type</dt>
            <dd className="mt-1 text-sm text-slate-900">{info.type}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-slate-500">Found on Page</dt>
            <dd className="mt-1 text-sm text-slate-900">{info.pageNumber}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-slate-500">Number of Rows</dt>
            <dd className="mt-1 text-sm text-slate-900">{info.rowCount}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-slate-500">Number of Columns</dt>
            <dd className="mt-1 text-sm text-slate-900">{info.columnCount}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-slate-500">Table Structure</dt>
            <dd className="mt-1 text-sm text-slate-900 capitalize">{info.structure}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-slate-500">Special Features</dt>
            <dd className="mt-1 text-sm text-slate-900">
              {info.specialFeatures && info.specialFeatures.length > 0
                ? info.specialFeatures.join(", ")
                : "None detected"}
            </dd>
          </div>
          <div className="sm:col-span-2">
            <dt className="text-sm font-medium text-slate-500">Detection Method</dt>
            <dd className="mt-1 text-sm text-slate-900">{info.detectionMethod}</dd>
          </div>
          <div className="sm:col-span-2">
            <dt className="text-sm font-medium text-slate-500">Extraction Notes</dt>
            <dd className="mt-1 text-sm text-slate-900">
              {info.extractionNotes || "Standard extraction without special processing"}
            </dd>
          </div>
        </dl>
      </CardContent>
    </Card>
  );
}
