import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  FileText,
  Home,
  FileSpreadsheet,
  Settings,
  HelpCircle,
} from "lucide-react";

interface MobileMenuLinkProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  active: boolean;
  onClick: () => void;
}

const MobileMenuLink = ({
  icon,
  label,
  href,
  active,
  onClick,
}: MobileMenuLinkProps) => {
  return (
    <Link href={href}>
      <a
        onClick={onClick}
        className={cn(
          "flex items-center px-2 py-2 text-base font-medium rounded-md",
          active
            ? "bg-slate-900 text-white"
            : "text-slate-300 hover:bg-slate-700 hover:text-white"
        )}
      >
        <div
          className={cn(
            "mr-3 h-6 w-6",
            active ? "text-primary-400" : "text-slate-400"
          )}
        >
          {icon}
        </div>
        {label}
      </a>
    </Link>
  );
};

export function MobileMenu() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  const closeMobileMenu = () => setOpen(false);

  const links = [
    {
      icon: <Home />,
      label: "Dashboard",
      href: "/",
    },
    {
      icon: <FileText />,
      label: "My Documents",
      href: "/documents",
    },
    {
      icon: <FileSpreadsheet />,
      label: "Extracted Tables",
      href: "/tables",
    },
    {
      icon: <Settings />,
      label: "Settings",
      href: "/settings",
    },
    {
      icon: <HelpCircle />,
      label: "Help",
      href: "/help",
    },
  ];

  return (
    <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow md:hidden">
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="px-4 border-r border-slate-200 text-slate-500">
            <span className="sr-only">Open sidebar</span>
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 bg-slate-800 text-white border-r border-slate-700">
          <SheetHeader className="p-4 border-b border-slate-700">
            <SheetTitle className="flex items-center text-white">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-primary-500"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              <span className="ml-2">Table Extractor</span>
            </SheetTitle>
          </SheetHeader>
          <nav className="mt-4 px-2 space-y-1">
            {links.map((link) => (
              <MobileMenuLink
                key={link.href}
                icon={link.icon}
                label={link.label}
                href={link.href}
                active={location === link.href}
                onClick={closeMobileMenu}
              />
            ))}
          </nav>
        </SheetContent>
      </Sheet>
      <div className="flex-1 px-4 flex justify-between">
        <div className="flex-1 flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-8 w-8 text-primary-500"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
          <h1 className="ml-2 text-slate-900 text-lg font-bold">Table Extractor</h1>
        </div>
      </div>
    </div>
  );
}
