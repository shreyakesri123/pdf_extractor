import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function UserProfile() {
  return (
    <div className="flex-shrink-0 flex border-t border-slate-700 p-4">
      <div className="flex-shrink-0 w-full group block">
        <div className="flex items-center">
          <div>
            <Avatar className="h-8 w-8 rounded-full bg-primary-600">
              <AvatarFallback className="text-sm font-medium leading-none text-white">
                JD
              </AvatarFallback>
            </Avatar>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-white">John Doe</p>
            <p className="text-xs font-medium text-slate-300">View profile</p>
          </div>
        </div>
      </div>
    </div>
  );
}
