import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { UserProfile } from "./user-profile";
import {
  FileText,
  Home,
  FileSpreadsheet,
  Settings,
  HelpCircle,
} from "lucide-react";

interface SidebarLinkProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  active: boolean;
}

const SidebarLink = ({ icon, label, href, active }: SidebarLinkProps) => {
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center px-2 py-2 text-sm font-medium rounded-md group",
          active
            ? "bg-slate-900 text-white"
            : "text-slate-300 hover:bg-slate-700 hover:text-white"
        )}
      >
        <div
          className={cn(
            "mr-3 h-6 w-6",
            active ? "text-primary-400" : "text-slate-400"
          )}
        >
          {icon}
        </div>
        {label}
      </a>
    </Link>
  );
};

export function Sidebar() {
  const [location] = useLocation();

  const links = [
    {
      icon: <Home />,
      label: "Dashboard",
      href: "/",
    },
    {
      icon: <FileText />,
      label: "My Documents",
      href: "/documents",
    },
    {
      icon: <FileSpreadsheet />,
      label: "Extracted Tables",
      href: "/tables",
    },
    {
      icon: <Settings />,
      label: "Settings",
      href: "/settings",
    },
    {
      icon: <HelpCircle />,
      label: "Help",
      href: "/help",
    },
  ];

  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 bg-slate-800">
        <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto">
          <div className="flex items-center justify-center flex-shrink-0 px-4">
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-primary-500"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              <h1 className="ml-2 text-white text-lg font-bold">Table Extractor</h1>
            </div>
          </div>
          <nav className="mt-8 flex-1 px-2 space-y-1">
            {links.map((link) => (
              <SidebarLink
                key={link.href}
                icon={link.icon}
                label={link.label}
                href={link.href}
                active={location === link.href}
              />
            ))}
          </nav>
        </div>
        <UserProfile />
      </div>
    </div>
  );
}
