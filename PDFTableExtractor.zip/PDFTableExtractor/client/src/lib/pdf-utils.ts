/**
 * Format a file size in bytes to a human-readable string
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) {
    return bytes + ' bytes';
  } else if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(1) + ' KB';
  } else {
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
}

/**
 * Format a date string to a human-readable format
 */
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Create a download URL for an Excel file
 */
export function createExcelDownloadUrl(documentId: number, tableId?: number): string {
  if (tableId !== undefined) {
    return `/api/tables/${tableId}/excel`;
  } else {
    return `/api/documents/${documentId}/excel`;
  }
}

/**
 * Download a file from a URL
 */
export async function downloadFile(url: string, filename: string): Promise<void> {
  try {
    console.log(`Attempting to download from URL: ${url}`);
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      },
    });
    
    console.log(`Response status: ${response.status}, ${response.statusText}`);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Download failed with status ${response.status}: ${errorText}`);
      throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
    }
    
    // Check content type to verify we received an Excel file
    const contentType = response.headers.get('Content-Type');
    console.log(`Content-Type of response: ${contentType}`);
    
    const blob = await response.blob();
    console.log(`Blob size: ${blob.size} bytes, type: ${blob.type}`);
    
    if (blob.size === 0) {
      throw new Error('Downloaded file is empty');
    }
    
    const downloadUrl = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = downloadUrl;
    a.download = filename;
    document.body.appendChild(a);
    console.log(`Created download element for file: ${filename}`);
    a.click();
    console.log('Download initiated');
    
    // Clean up
    setTimeout(() => {
      window.URL.revokeObjectURL(downloadUrl);
      a.remove();
      console.log('Download cleanup complete');
    }, 100);
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('Error downloading file:', err);
    alert(`Failed to download file: ${errorMessage}`);
    throw err;
  }
}

/**
 * Calculate a simulated accuracy score for the extraction
 * In a real implementation, this would be based on actual validation metrics
 */
export function calculateExtractionAccuracy(tables: any[]): number {
  if (!tables || tables.length === 0) return 0;
  
  // Simple heuristic: More tables and more complex features suggest higher accuracy
  const baseScore = 85; // Start with a reasonable base score
  
  // Add points for each table (diminishing returns)
  const tableCount = Math.min(tables.length, 5); // Cap at 5 tables
  const tableBonus = tableCount * 2; // 2 points per table, up to 10 points
  
  // Analyze complexity and special features across tables
  let complexityScore = 0;
  let featureCount = 0;
  
  for (const table of tables) {
    // More columns and rows indicate more complex tables
    const colCount = table.info?.columnCount || 0;
    const rowCount = table.info?.rowCount || 0;
    
    // Add complexity points based on table size
    if (colCount >= 5 && rowCount >= 10) complexityScore += 1;
    if (colCount >= 8 && rowCount >= 20) complexityScore += 1;
    
    // Count special features
    featureCount += (table.info?.specialFeatures?.length || 0);
  }
  
  // Cap complexity score
  complexityScore = Math.min(complexityScore, 3); // Maximum 3 points
  
  // Feature score (diminishing returns)
  const featureScore = Math.min(featureCount, 2); // Maximum 2 points
  
  // Calculate final score
  const finalScore = baseScore + tableBonus + complexityScore + featureScore;
  
  // Cap at 100%
  return Math.min(finalScore, 100);
}