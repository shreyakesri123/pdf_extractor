import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ExtractedTableData, PdfExtractionResponse } from "@shared/schema";
import { createExcelDownloadUrl, downloadFile, formatFileSize, formatDate } from "@/lib/pdf-utils";

// Main Home Page Component
export default function Home() {
  const [isUploading, setIsUploading] = useState(false);
  const [document, setDocument] = useState<PdfExtractionResponse | null>(null);
  const [selectedTableIndex, setSelectedTableIndex] = useState<number>(0);
  const [downloadInProgress, setDownloadInProgress] = useState(false);

  // Mutation for uploading and processing PDF
  const mutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("pdf", file);

      const response = await apiRequest<PdfExtractionResponse>("/api/extract", {
        method: "POST",
        body: formData,
      });

      return response;
    },
    onMutate: () => {
      setIsUploading(true);
    },
    onSuccess: (data) => {
      setDocument(data);
      setIsUploading(false);
      setSelectedTableIndex(0); // Reset to the first table
    },
    onError: (error) => {
      console.error("Error processing PDF:", error);
      setIsUploading(false);
      alert("Failed to process PDF. Please try again.");
    },
  });

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Reset state
      setDocument(null);
      setSelectedTableIndex(0);
      // Process the file
      mutation.mutate(file);
    }
  };

  // Handle Excel download with loading state
  const handleDownload = async (documentId: number, consolidated: boolean = false, tableIndex?: number) => {
    try {
      setDownloadInProgress(true);
      
      let url = '';
      let filename = '';
      
      if (consolidated) {
        url = `/api/documents/${documentId}/excel`;
        filename = `${document?.filename.replace('.pdf', '') || 'document'}-tables.xlsx`;
      } else {
        // Use the specified table index or the selected one
        const idx = tableIndex !== undefined ? tableIndex : selectedTableIndex;
        const table = document?.tables[idx];
        if (!table) return;
        
        url = `/api/tables/${table.tableIndex}/excel`;
        filename = `${document?.filename.replace('.pdf', '') || 'document'}-${table.info.type.replace(/\s+/g, '-').toLowerCase()}.xlsx`;
      }
      
      console.log(`Starting download for: ${url} as ${filename}`);
      await downloadFile(url, filename);
      console.log('Download completed successfully');
    } catch (error) {
      console.error("Error downloading Excel:", error);
      alert("Failed to download Excel file. Please try again.");
    } finally {
      setDownloadInProgress(false);
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent mb-2">
          PDF Table Extractor
        </h1>
        <p className="text-gray-600">
          Extract tables from financial documents and bank statements to Excel
        </p>
      </header>

      {/* File Upload Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <svg className="w-6 h-6 mr-2 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path>
          </svg>
          Upload Financial Document
        </h2>
        <div className="flex items-center justify-center w-full">
          <label
            htmlFor="pdf-upload"
            className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer border-gray-300 hover:bg-gray-50 hover:border-primary transition-colors"
          >
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              {isUploading ? (
                <div className="text-center">
                  <div className="animate-spin inline-block w-8 h-8 border-4 border-current border-t-transparent text-primary rounded-full mb-2"></div>
                  <p className="text-sm text-gray-500">Processing your financial document...</p>
                  <p className="text-xs text-gray-400 mt-2">This may take a few moments</p>
                </div>
              ) : (
                <>
                  <svg
                    className="w-12 h-12 mb-3 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    ></path>
                  </svg>
                  <p className="mb-2 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-gray-500">
                    Supports bank statements, financial reports, and other tabular PDFs (Max 10MB)
                  </p>
                </>
              )}
            </div>
            <input
              id="pdf-upload"
              type="file"
              accept=".pdf"
              className="hidden"
              onChange={handleFileUpload}
              disabled={isUploading}
            />
          </label>
        </div>
      </div>

      {/* Results Section */}
      {document && document.tables.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          {/* Document Info Section */}
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <div className="flex flex-wrap justify-between items-start">
              <div className="mb-4 md:mb-0">
                <h2 className="text-xl font-semibold mb-2 flex items-center">
                  <svg className="w-5 h-5 mr-2 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  Document Information
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2 text-sm">
                  <div>
                    <span className="font-medium text-gray-600">Filename:</span> {document.filename}
                  </div>
                  <div>
                    <span className="font-medium text-gray-600">File Size:</span> {formatFileSize(document.filesize)}
                  </div>
                  <div>
                    <span className="font-medium text-gray-600">Uploaded:</span> {formatDate(document.uploadDate)}
                  </div>
                  <div>
                    <span className="font-medium text-gray-600">Tables Found:</span> {document.tables.length}
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col space-y-2">
                <button
                  onClick={() => handleDownload(document.documentId, false, selectedTableIndex)}
                  disabled={downloadInProgress}
                  className={`px-4 py-2 bg-primary text-white rounded hover:bg-primary/90 flex items-center justify-center transition-colors ${downloadInProgress ? 'opacity-70 cursor-not-allowed' : ''}`}
                >
                  {downloadInProgress ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Downloading...
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                      </svg>
                      Download Selected Table
                    </>
                  )}
                </button>
                
                {document.tables.length > 1 && (
                  <button
                    onClick={() => handleDownload(document.documentId, true)}
                    disabled={downloadInProgress}
                    className={`px-4 py-2 border border-primary text-primary rounded hover:bg-primary/10 flex items-center justify-center transition-colors ${downloadInProgress ? 'opacity-70 cursor-not-allowed' : ''}`}
                  >
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    Download All Tables
                  </button>
                )}
              </div>
            </div>
          </div>
          
          {/* Table Navigation Tabs */}
          {document.tables.length > 1 && (
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-3">Available Tables:</h3>
              <div className="flex flex-wrap gap-2">
                {document.tables.map((table, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedTableIndex(index)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedTableIndex === index
                        ? 'bg-primary text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {table.info.type}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Selected Table Preview */}
          {document.tables[selectedTableIndex] && (
            <div className="space-y-6">
              <EnhancedTablePreview table={document.tables[selectedTableIndex]} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Enhanced Table Preview Component with better styling for financial data
function EnhancedTablePreview({ table }: { table: ExtractedTableData }) {
  const { data, info } = table;

  // Get display columns based on table type
  const getDisplayColumns = () => {
    const headers = data.headers.map(h => h.toLowerCase());
    
    // For transaction tables, prioritize important columns
    if (info.type === 'Bank Statement') {
      const priorityHeaders = ['date', 'amount', 'description', 'debit', 'credit', 'balance'];
      const importantIndices = headers.map((header, index) => {
        const isImportant = priorityHeaders.some(priority => header.includes(priority));
        return isImportant ? index : -1;
      }).filter(index => index !== -1);
      
      // If we found important columns, return those (up to 5)
      if (importantIndices.length > 0) {
        return importantIndices.slice(0, 5);
      }
    }
    
    // Default approach - just take the first 5
    return Array.from({ length: Math.min(data.headers.length, 5) }, (_, i) => i);
  };
  
  const displayColumnIndices = getDisplayColumns();
  const displayRows = Math.min(data.rows.length, 8); // Show more rows for bank statements
  
  // Format cell value based on content
  const formatCellValue = (text: string, columnHeader: string) => {
    const headerLower = columnHeader.toLowerCase();
    
    // Format amount/money values
    if (
      headerLower.includes('amount') || 
      headerLower.includes('balance') || 
      (headerLower.includes('debit') && !headerLower.includes('debit/credit')) || 
      (headerLower.includes('credit') && !headerLower.includes('debit/credit'))
    ) {
      if (text.match(/^-?[\d,]+(\.\d+)?$/)) {
        const isNegative = text.startsWith('-');
        const formattedValue = text.replace(/^-/, '');
        
        return (
          <span className={isNegative ? 'text-red-600' : 'text-green-600'}>
            {isNegative ? '-' : ''}{formattedValue}
          </span>
        );
      }
    }
    
    // Format debit/credit indicators
    if (headerLower === 'debit/credit' || headerLower === 'd/c') {
      if (text === 'D' || text === 'd') {
        return <span className="text-red-600 font-medium">Debit</span>;
      } else if (text === 'C' || text === 'c') {
        return <span className="text-green-600 font-medium">Credit</span>;
      }
    }
    
    // Default
    return text;
  };

  return (
    <div className="border rounded-lg overflow-hidden border-gray-200">
      <div className="bg-gray-50 p-4">
        <h3 className="font-medium text-lg flex items-center">
          {info.type === 'Bank Statement' ? (
            <svg className="w-5 h-5 mr-2 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
            </svg>
          ) : (
            <svg className="w-5 h-5 mr-2 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
            </svg>
          )}
          {info.type} (Page {info.pageNumber})
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3 text-sm">
          <div>
            <span className="text-gray-500">Rows:</span> <span className="font-medium">{info.rowCount}</span>
          </div>
          <div>
            <span className="text-gray-500">Columns:</span> <span className="font-medium">{info.columnCount}</span>
          </div>
          <div>
            <span className="text-gray-500">Structure:</span> <span className="font-medium capitalize">{info.structure}</span>
          </div>
          {info.specialFeatures && info.specialFeatures.length > 0 && (
            <div>
              <span className="text-gray-500">Features:</span> <span className="font-medium">{info.specialFeatures[0]}</span>
            </div>
          )}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-primary">
            <tr>
              {displayColumnIndices.map((columnIndex) => (
                <th
                  key={columnIndex}
                  className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider"
                >
                  {data.headers[columnIndex]}
                </th>
              ))}
              {data.headers.length > displayColumnIndices.length && (
                <th className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                  ...
                </th>
              )}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.rows.slice(0, displayRows).map((row, rowIndex) => (
              <tr key={rowIndex} className={rowIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {displayColumnIndices.map((columnIndex) => (
                  <td
                    key={columnIndex}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-700"
                  >
                    {formatCellValue(row[columnIndex]?.text || '', data.headers[columnIndex])}
                  </td>
                ))}
                {data.headers.length > displayColumnIndices.length && (
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ...
                  </td>
                )}
              </tr>
            ))}
            {data.rows.length > displayRows && (
              <tr>
                <td
                  colSpan={displayColumnIndices.length + (data.headers.length > displayColumnIndices.length ? 1 : 0)}
                  className="px-6 py-4 text-sm text-gray-500 text-center border-t border-gray-200 bg-gray-50"
                >
                  <span className="font-medium text-primary">
                    + {data.rows.length - displayRows} more rows available in Excel export
                  </span>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Additional information */}
      {info.extractionNotes && (
        <div className="p-3 bg-gray-50 text-sm text-gray-600 border-t border-gray-200">
          <span className="font-medium">Note:</span> {info.extractionNotes}
        </div>
      )}
    </div>
  );
}