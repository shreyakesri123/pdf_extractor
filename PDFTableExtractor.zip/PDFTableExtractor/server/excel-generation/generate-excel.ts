/**
 * Excel generation module for table extraction
 * 
 * This module converts extracted table data to Excel spreadsheets
 * with special handling for financial data
 */
import * as xlsx from 'xlsx';
import { TableData } from '@shared/schema';

/**
 * Generate Excel file for a single table
 */
export async function generateExcelFile(
  tableData: TableData,
): Promise<Buffer> {
  try {
    console.log(`Generating Excel for table with ${tableData.rows.length} rows and ${tableData.headers.length} columns`);
    
    // Create workbook
    const workbook = xlsx.utils.book_new();
    
    // Convert table to worksheet
    const worksheet = convertTableToWorksheet(tableData);
    
    // Apply styling based on table type
    applyExcelStyling(worksheet, tableData);
    
    // Determine sheet name based on content
    const sheetName = determineSheetName(tableData);
    
    // Add worksheet to workbook
    xlsx.utils.book_append_sheet(workbook, worksheet, sheetName);
    
    // Write to buffer
    const excelBuffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    
    console.log(`Excel file generated successfully, size: ${excelBuffer.length} bytes`);
    return excelBuffer;
  } catch (error) {
    console.error('Error generating Excel file:', error);
    throw new Error(`Excel generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Generate consolidated Excel file with multiple tables as sheets
 */
export async function generateConsolidatedExcel(
  tables: TableData[]
): Promise<Buffer> {
  try {
    console.log(`Generating consolidated Excel with ${tables.length} tables`);
    
    // Create workbook
    const workbook = xlsx.utils.book_new();
    
    // Add each table as a separate sheet
    for (let i = 0; i < tables.length; i++) {
      const tableData = tables[i];
      
      // Convert table to worksheet
      const worksheet = convertTableToWorksheet(tableData);
      
      // Apply styling
      applyExcelStyling(worksheet, tableData);
      
      // Determine appropriate sheet name
      const sheetName = determineBankStatementSheetName(tableData, i);
      
      // Add worksheet to workbook
      try {
        xlsx.utils.book_append_sheet(workbook, worksheet, sheetName);
        console.log(`Added sheet: ${sheetName}`);
      } catch (err) {
        console.warn(`Warning: Could not add sheet "${sheetName}" - possibly duplicate name. Using fallback name.`);
        // Use a fallback name in case of duplicates
        xlsx.utils.book_append_sheet(workbook, worksheet, `Table ${i + 1}`);
      }
    }
    
    // Write to buffer
    const excelBuffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    
    console.log(`Consolidated Excel file generated successfully, size: ${excelBuffer.length} bytes`);
    return excelBuffer;
  } catch (error) {
    console.error('Error generating consolidated Excel file:', error);
    throw new Error(`Consolidated Excel generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Determine an appropriate sheet name based on table content
 */
function determineSheetName(tableData: TableData): string {
  // Check headers to see if it's a banking/financial table
  const headers = tableData.headers.map(h => h.toLowerCase());
  
  if (headers.includes('transaction date') || headers.includes('transaction amount')) {
    return 'Transactions';
  } else if (headers.includes('description') && headers.includes('value')) {
    return 'Account Summary';
  } else if (headers.includes('debit') && headers.includes('credit')) {
    return 'Financial Data';
  } else {
    return 'Table Data';
  }
}

/**
 * Determine sheet name for bank statement tables
 */
function determineBankStatementSheetName(tableData: TableData, index: number): string {
  // Look for specific banking-related keywords in headers
  const headersText = tableData.headers.join(' ').toLowerCase();
  
  if (headersText.includes('transaction') && headersText.includes('amount')) {
    return 'Transactions';
  } else if (headersText.includes('opening balance') || headersText.includes('closing balance')) {
    return 'Account Summary';
  } else if (headersText.includes('debit') || headersText.includes('credit')) {
    return 'Statement Details';
  } else if (tableData.headers.length === 2 && tableData.rows.length > 5) {
    // Possibly a key-value table with account information
    return 'Account Information';
  } else {
    return `Table ${index + 1}`;
  }
}

/**
 * Convert a table to xlsx worksheet format
 */
function convertTableToWorksheet(tableData: TableData): xlsx.WorkSheet {
  // Prepare data for worksheet (headers + rows)
  const worksheetData = [
    tableData.headers, // First row is headers
    ...tableData.rows.map(row => row.map(cell => cell.text)) // Map each row's cell to just its text content
  ];
  
  // Create worksheet
  const worksheet = xlsx.utils.aoa_to_sheet(worksheetData);
  
  return worksheet;
}

/**
 * Apply styling to Excel worksheet
 * 
 * Enhanced with better financial data formatting and styling
 */
function applyExcelStyling(worksheet: xlsx.WorkSheet, tableData: TableData): void {
  // Get column range
  const range = xlsx.utils.decode_range(worksheet['!ref'] || 'A1:A1');
  
  // Apply header styling - blue background for headers
  for (let col = range.s.c; col <= range.e.c; col++) {
    const cellAddress = xlsx.utils.encode_cell({ r: 0, c: col });
    
    // Apply bold font to headers with light blue background
    if (!worksheet[cellAddress].s) worksheet[cellAddress].s = {};
    worksheet[cellAddress].s = {
      font: { bold: true, color: { rgb: "FFFFFF" } },
      fill: { fgColor: { rgb: "4472C4" } },
      alignment: { horizontal: "center" }
    };
  }
  
  // Format specific columns based on content type (e.g., financial data)
  for (let row = 1; row <= range.e.r; row++) {
    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = xlsx.utils.encode_cell({ r: row, c: col });
      if (!worksheet[cellAddress]) continue;
      
      const headerText = tableData.headers[col]?.toLowerCase() || '';
      const cellValue = worksheet[cellAddress].v;
      
      // Skip empty cells
      if (cellValue === undefined || cellValue === null || cellValue === '') continue;
      
      // Apply cell styling based on content
      if (!worksheet[cellAddress].s) worksheet[cellAddress].s = {};
      
      // Apply number formatting for amount columns
      if (
        headerText.includes('amount') || 
        headerText.includes('balance') || 
        headerText.includes('debit') || 
        headerText.includes('credit')
      ) {
        // Apply number formatting
        if (typeof cellValue === 'string' && cellValue.match(/^-?[\d,]+(\.\d+)?$/)) {
          // It's a numeric string with commas, apply currency format
          worksheet[cellAddress].s.numFmt = '#,##0.00';
        }
      }
      
      // Apply date formatting for date columns
      if (
        headerText.includes('date')
      ) {
        worksheet[cellAddress].s.numFmt = 'yyyy-mm-dd';
      }
      
      // Highlight debit/credit indicators
      if (
        headerText === 'debit/credit' || 
        headerText === 'd/c'
      ) {
        if (cellValue === 'D' || cellValue === 'd') {
          // Debit in red
          worksheet[cellAddress].s.font = { color: { rgb: "FF0000" } };
        } else if (cellValue === 'C' || cellValue === 'c') {
          // Credit in green
          worksheet[cellAddress].s.font = { color: { rgb: "00B050" } };
        }
      }
      
      // Zebra striping for rows
      if (row % 2 === 0) {
        worksheet[cellAddress].s.fill = { fgColor: { rgb: "F2F2F2" } };
      }
    }
  }
  
  // Apply column width adjustments for better readability
  const colWidths = [];
  
  for (let i = 0; i < tableData.headers.length; i++) {
    const header = tableData.headers[i];
    
    // Determine width based on content type
    let width;
    const headerLower = header.toLowerCase();
    
    if (headerLower.includes('details') || headerLower.includes('description')) {
      // Wide columns for descriptions or transaction details
      width = 50;
    } else if (headerLower.includes('reference')) {
      // Medium width for reference numbers
      width = 20;
    } else if (headerLower.includes('date')) {
      // Fixed width for dates
      width = 15;
    } else if (headerLower.includes('amount') || headerLower.includes('balance')) {
      // Numeric columns
      width = 15;
    } else {
      // Default width based on header length
      width = Math.max(10, header.length * 1.2);
    }
    
    colWidths.push(width);
  }
  
  // Update column widths
  const cols = colWidths.map(width => ({ width }));
  worksheet['!cols'] = cols;
}