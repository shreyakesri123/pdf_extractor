/**
 * Type declarations for PDF.js worker, which is not fully typed in the PDF.js package.
 * 
 * These type declarations provide minimal coverage of the worker-related aspects 
 * of PDF.js when used in a Node.js environment.
 */

declare module 'pdfjs-dist/legacy/build/pdf.worker.js' {
  export const WorkerMessageHandler: any;
}

declare global {
  interface Window {
    DOMMatrix: any;
    Path2D: any;
    ImageData: any;
  }
}