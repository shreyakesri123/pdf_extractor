/**
 * Main PDF table extraction module
 * 
 * This module handles the extraction of tables from PDF documents
 * using PDF.js and custom table detection algorithms
 */
import pdfjs from './preload';
import { analyzeTextPositions } from './text-analysis';
import { detectTables } from './table-detection';
import { ExtractedTableData, TableData, TableInfo } from '@shared/schema';

// Debug check for PDF.js
console.log('PDF.js loaded:', !!pdfjs);
console.log('PDF.js getDocument:', typeof pdfjs.getDocument);

// Type definitions for PDF.js objects
interface CustomTextItem {
  str: string;
  transform: number[];
  width: number;
  height: number;
  fontName?: string;
}

interface CustomTextContent {
  items: CustomTextItem[];
  styles?: Record<string, any>;
}

interface CustomViewport {
  width: number;
  height: number;
}

/**
 * Main function to extract tables from a PDF buffer
 */
export async function extractTablesFromPdf(pdfBuffer: Buffer): Promise<ExtractedTableData[]> {
  try {
    // Load the PDF document
    const loadingTask = pdfjs.getDocument({ 
      data: pdfBuffer
    });
    const document = await loadingTask.promise;
    
    console.log(`PDF loaded successfully. Number of pages: ${document.numPages}`);
    
    // Array to store all extracted tables
    const extractedTables: ExtractedTableData[] = [];
    let tableIndex = 0;
    
    // Process each page
    for (let pageNum = 1; pageNum <= document.numPages; pageNum++) {
      try {
        console.log(`Processing page ${pageNum}/${document.numPages}`);
        
        // Get the page
        const pdfJsPage = await document.getPage(pageNum);
        
        // Extract text content from the page
        const textContent = await pdfJsPage.getTextContent() as CustomTextContent;
        const viewport = pdfJsPage.getViewport({ scale: 1.0 }) as CustomViewport;
        
        // Analyze text positions
        const textPositionData = analyzeTextPositions(textContent, viewport);
        
        // Detect tables in the analyzed text
        const detectedTables = detectTables(textPositionData, viewport);
        
        console.log(`Found ${detectedTables.length} tables on page ${pageNum}`);
        
        // Process each detected table
        for (const detectedTable of detectedTables) {
          // Convert detected table to our schema format
          const tableData: TableData = {
            headers: detectedTable.headers,
            rows: detectedTable.rows
          };
          
          // Create table metadata
          const tableInfo: TableInfo = {
            type: detectedTable.type || 'Data Table',
            pageNumber: pageNum,
            rowCount: detectedTable.rows.length,
            columnCount: detectedTable.headers.length,
            structure: detectedTable.structure || 'mixed',
            specialFeatures: detectedTable.specialFeatures || [],
            detectionMethod: 'Automatic Pattern Detection',
            extractionNotes: detectedTable.extractionNotes || 'Table extracted with standard processing'
          };
          
          // Add to extracted tables array
          extractedTables.push({
            tableIndex: tableIndex++,
            data: tableData,
            info: tableInfo
          });
        }
      } catch (pageError) {
        console.error(`Error processing page ${pageNum}:`, pageError);
        // Continue with next page
      }
    }
    
    console.log(`Total tables extracted: ${extractedTables.length}`);
    
    return extractedTables;
  } catch (error) {
    console.error('Error extracting tables from PDF:', error);
    throw new Error(`PDF extraction failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}