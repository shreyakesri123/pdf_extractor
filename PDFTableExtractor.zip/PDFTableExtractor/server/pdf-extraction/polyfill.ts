/**
 * Polyfill module for PDF.js
 * 
 * This module provides polyfills for browser objects required by PDF.js
 * when running in a Node.js environment.
 */

/**
 * DOM Matrix implementation for Node.js
 * 
 * Provides a minimal implementation of the browser's DOMMatrix class,
 * with just enough functionality to satisfy PDF.js's requirements.
 */
class NodeDOMMatrix {
  a = 1; b = 0; c = 0; d = 1; e = 0; f = 0;
  m11 = 1; m12 = 0; m13 = 0; m14 = 0;
  m21 = 0; m22 = 1; m23 = 0; m24 = 0;
  m31 = 0; m32 = 0; m33 = 1; m34 = 0;
  m41 = 0; m42 = 0; m43 = 0; m44 = 1;
  is2D = true;
  isIdentity = true;

  constructor(init?: string | number[]) {
    if (init && Array.isArray(init) && init.length === 6) {
      // Handle 2D transform matrix [a, b, c, d, e, f]
      [this.a, this.b, this.c, this.d, this.e, this.f] = init;
      this.m11 = this.a; this.m12 = this.c; this.m13 = 0; this.m14 = 0;
      this.m21 = this.b; this.m22 = this.d; this.m23 = 0; this.m24 = 0;
      this.m31 = 0; this.m32 = 0; this.m33 = 1; this.m34 = 0;
      this.m41 = this.e; this.m42 = this.f; this.m43 = 0; this.m44 = 1;
      
      this.is2D = true;
      this.isIdentity = this.a === 1 && this.b === 0 && this.c === 0 && this.d === 1 && this.e === 0 && this.f === 0;
    }
  }

  translate() { return this; }
  scale() { return this; }
  rotate() { return this; }
  multiply() { return this; }
  transformPoint() { return { x: 0, y: 0, z: 0, w: 1 }; }
  toJSON() { return {}; }
}

/**
 * Path2D implementation for Node.js
 * 
 * Provides a minimal implementation of the browser's Path2D class,
 * with stub methods to satisfy PDF.js's requirements.
 */
class NodePath2D {
  addPath() {}
  arc() {}
  arcTo() {}
  bezierCurveTo() {}
  closePath() {}
  ellipse() {}
  lineTo() {}
  moveTo() {}
  quadraticCurveTo() {}
  rect() {}
}

/**
 * ImageData implementation for Node.js
 * 
 * Provides a minimal implementation of the browser's ImageData class,
 * to satisfy PDF.js's requirements.
 */
class NodeImageData {
  data: Uint8ClampedArray;
  width: number;
  height: number;
  colorSpace: string;

  constructor(data: Uint8ClampedArray | number, width: number, height?: number) {
    if (typeof data === 'number') {
      // Constructor overload: ImageData(width, height)
      this.width = data;
      this.height = width;
      this.data = new Uint8ClampedArray(this.width * this.height * 4);
    } else {
      // Constructor overload: ImageData(data, width, height)
      this.data = data;
      this.width = width;
      this.height = height || (data.length / (width * 4));
    }
    this.colorSpace = 'srgb';
  }
}

/**
 * Apply all the necessary polyfills for PDF.js in Node.js
 */
export function applyPolyfills(): void {
  // Apply polyfills to global
  (global as any).DOMMatrix = NodeDOMMatrix;
  (global as any).Path2D = NodePath2D;
  (global as any).ImageData = NodeImageData;
  
  // Additional Canvas-related polyfills PDF.js might need
  (global as any).OffscreenCanvas = class {
    width: number;
    height: number;
    
    constructor(width: number, height: number) {
      this.width = width;
      this.height = height;
    }
    
    getContext() {
      return {
        fillRect: () => {},
        drawImage: () => {},
        getImageData: () => new NodeImageData(1, 1),
        putImageData: () => {},
      };
    }
  };

  console.log('PDF.js polyfills applied.');
}