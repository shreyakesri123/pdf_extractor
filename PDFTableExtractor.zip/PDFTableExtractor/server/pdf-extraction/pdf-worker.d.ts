/**
 * Type declarations for PDF.js worker module
 */
declare module 'pdfjs-dist/legacy/build/pdf.worker.js' {
  export const WorkerMessageHandler: any;
}