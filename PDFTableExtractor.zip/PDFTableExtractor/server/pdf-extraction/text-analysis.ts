/**
 * Text analysis module for PDF table extraction
 * 
 * This module analyzes text positions from PDF content to identify potential
 * tabular structures based on alignment patterns.
 */

// Types for PDF.js content
interface TextItem {
  str: string;
  transform: number[];
  width: number;
  height: number;
  fontName?: string;
}

interface TextContent {
  items: TextItem[];
  styles?: Record<string, any>;
}

interface Viewport {
  width: number;
  height: number;
}

// Types for analyzed text positions
interface TextPositionData {
  items: Array<{
    text: string;
    x: number;
    y: number;
    width: number;
    height: number;
    fontName: string;
    isBold: boolean;
  }>;
  lines: Array<{
    y: number;
    items: Array<{
      text: string;
      x: number;
      width: number;
    }>;
  }>;
  columns: number[][];
}

/**
 * Analyze text positions from PDF text content
 */
export function analyzeTextPositions(
  textContent: TextContent,
  viewport: Viewport
): TextPositionData {
  // Extract positions and properties of each text item
  const items = textContent.items.map((item) => {
    // PDF.js transform is a matrix [a, b, c, d, e, f] where e,f are the coordinates
    const [, , , , x, y] = item.transform;
    
    // Determine if font is bold (approximate detection)
    const fontName = item.fontName || '';
    const isBold = fontName.includes('Bold') || fontName.includes('bold');
    
    return {
      text: item.str,
      x,
      y: viewport.height - y, // Convert PDF coordinate system (origin at bottom-left) to top-left origin
      width: item.width,
      height: item.height || 10, // Default height if not provided
      fontName,
      isBold,
    };
  });
  
  // Group items by line (y-position)
  const lineGroups: Map<number, typeof items> = new Map();
  
  // Group with tolerance for y-positions
  const yTolerance = 3; // 3 pixels tolerance for grouping lines
  
  for (const item of items) {
    // Find a line group that this item belongs to
    let foundGroup = false;
    for (const [groupY, groupItems] of lineGroups.entries()) {
      if (Math.abs(item.y - groupY) <= yTolerance) {
        groupItems.push(item);
        foundGroup = true;
        break;
      }
    }
    
    // If no suitable group found, create a new one
    if (!foundGroup) {
      lineGroups.set(item.y, [item]);
    }
  }
  
  // Create sorted lines
  const lines = Array.from(lineGroups.entries())
    .map(([y, itemsInLine]) => ({
      y,
      items: itemsInLine
        .sort((a, b) => a.x - b.x)
        .map(item => ({
          text: item.text,
          x: item.x,
          width: item.width,
        })),
    }))
    .sort((a, b) => a.y - b.y);
  
  // Analyze columns
  const columns = analyzeColumns(lines);
  
  return {
    items,
    lines,
    columns,
  };
}

/**
 * Analyze and detect column structures
 */
function analyzeColumns(
  lines: Array<{
    y: number;
    items: Array<{
      text: string;
      x: number;
      width: number;
    }>;
  }>
): number[][] {
  // Extract x-positions from each line
  const linePositions = lines.map(line => 
    line.items.map(item => Math.round(item.x))
  );
  
  // Only consider lines with at least 3 items (potential table rows)
  const potentialTableLines = linePositions.filter(positions => positions.length >= 3);
  
  if (potentialTableLines.length < 3) {
    // Not enough potential table lines
    return [];
  }
  
  // Cluster similar positions across lines
  const columnSets: number[][] = [];
  
  for (const positions of potentialTableLines) {
    // Try to find a similar existing column set
    let foundSimilar = false;
    
    for (const existingSet of columnSets) {
      if (arePositionsSimilar(positions, existingSet)) {
        foundSimilar = true;
        break;
      }
    }
    
    if (!foundSimilar) {
      // This is a new column pattern
      columnSets.push([...positions]);
    }
  }
  
  // Cluster positions within each set
  const clusteredColumnSets = columnSets.map(positions => 
    clusterPositions(positions, 10) // 10px threshold for considering positions as the same column
  );
  
  // Find most consistent column set
  return findMostConsistentColumnSet(clusteredColumnSets);
}

/**
 * Cluster x-positions that are close to each other
 */
function clusterPositions(positions: number[], threshold: number): number[] {
  if (positions.length === 0) return [];
  
  // Sort positions
  const sortedPositions = [...positions].sort((a, b) => a - b);
  
  // Cluster positions
  const clusters: number[][] = [];
  let currentCluster: number[] = [sortedPositions[0]];
  
  for (let i = 1; i < sortedPositions.length; i++) {
    const currentPos = sortedPositions[i];
    const prevPos = sortedPositions[i - 1];
    
    if (currentPos - prevPos <= threshold) {
      // Add to current cluster
      currentCluster.push(currentPos);
    } else {
      // Start a new cluster
      clusters.push(currentCluster);
      currentCluster = [currentPos];
    }
  }
  
  // Add last cluster
  clusters.push(currentCluster);
  
  // Calculate average position for each cluster
  return clusters.map(cluster => 
    Math.round(cluster.reduce((sum, pos) => sum + pos, 0) / cluster.length)
  );
}

/**
 * Check if two sets of positions are similar
 */
function arePositionsSimilar(positions1: number[], positions2: number[]): boolean {
  // Simple heuristic: Consider similar if at least 70% of positions are within 10px of each other
  const threshold = 10;
  const minMatches = Math.min(positions1.length, positions2.length) * 0.7;
  
  let matches = 0;
  
  for (const pos1 of positions1) {
    for (const pos2 of positions2) {
      if (Math.abs(pos1 - pos2) <= threshold) {
        matches++;
        break;
      }
    }
  }
  
  return matches >= minMatches;
}

/**
 * Find the most consistent column set
 */
function findMostConsistentColumnSet(columnSets: number[][]): number[][] {
  if (columnSets.length === 0) return [];
  
  // Count how many times each column set pattern appears
  const patternCounts: Map<string, { count: number, set: number[] }> = new Map();
  
  for (const set of columnSets) {
    // Create a simplified pattern based on number of columns and relative spacing
    const patternKey = set.length.toString();
    
    const existingPattern = patternCounts.get(patternKey);
    if (existingPattern) {
      existingPattern.count++;
      // Check if sets are similar
      if (areColumnSetsSimilar(set, existingPattern.set)) {
        // Merge sets by averaging column positions
        existingPattern.set = set.map((pos, i) => 
          Math.round((pos + existingPattern.set[i]) / 2)
        );
      }
    } else {
      patternCounts.set(patternKey, { count: 1, set });
    }
  }
  
  // Find the most frequent pattern
  let mostFrequentPattern: { count: number, set: number[] } | null = null;
  
  for (const [, pattern] of patternCounts.entries()) {
    if (!mostFrequentPattern || pattern.count > mostFrequentPattern.count) {
      mostFrequentPattern = pattern;
    }
  }
  
  // Return the sets that match this pattern
  return columnSets.filter(set => 
    mostFrequentPattern && 
    set.length === mostFrequentPattern.set.length && 
    areColumnSetsSimilar(set, mostFrequentPattern.set)
  );
}

/**
 * Check if two column sets are similar
 */
function areColumnSetsSimilar(set1: number[], set2: number[]): boolean {
  if (set1.length !== set2.length) return false;
  
  // Check if relative spacing between columns is similar
  const threshold = 10; // 10px threshold
  
  for (let i = 0; i < set1.length; i++) {
    if (Math.abs(set1[i] - set2[i]) > threshold) {
      return false;
    }
  }
  
  return true;
}