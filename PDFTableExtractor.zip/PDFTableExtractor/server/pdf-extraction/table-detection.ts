/**
 * Table detection module for PDF table extraction
 * 
 * This module implements algorithms to detect and extract table structures
 * from text position data analyzed from PDF content.
 */
import { TableCell } from '@shared/schema';

// Types for text position data
interface TextPositionData {
  items: Array<{
    text: string;
    x: number;
    y: number;
    width: number;
    height: number;
    fontName: string;
    isBold: boolean;
  }>;
  lines: Array<{
    y: number;
    items: Array<{
      text: string;
      x: number;
      width: number;
    }>;
  }>;
  columns: number[][];
}

// Types for detected tables
interface DetectedTable {
  headers: string[];
  rows: TableCell[][];
  type?: string;
  structure?: 'bordered' | 'borderless' | 'mixed';
  specialFeatures?: string[];
  extractionNotes?: string;
}

// Type for viewport dimensions
interface Viewport {
  width: number;
  height: number;
}

/**
 * Detect tables in a PDF page based on text positioning analysis
 */
export function detectTables(textPositionData: TextPositionData, viewport: Viewport): DetectedTable[] {
  const detectedTables: DetectedTable[] = [];
  
  // First try to identify tables based on structural patterns
  const tableStructures = identifyTableStructures(textPositionData);
  
  console.log(`Identified ${tableStructures.length} potential table structures`);
  
  // For each identified structure, extract the table data
  for (const structure of tableStructures) {
    const table = extractTableData(
      structure.startLine,
      structure.endLine,
      structure.columns,
      textPositionData
    );
    
    if (table.headers.length > 0 && table.rows.length > 0) {
      // Enhance with additional table metadata
      table.type = inferTableType(table.headers);
      table.structure = determineTableStructure(textPositionData, structure.startLine, structure.endLine);
      
      // Detect special features
      const specialFeatures: string[] = [];
      if (hasMultiLineCells(table.rows)) specialFeatures.push('Multi-line cells');
      if (hasMergedCells(table.rows)) specialFeatures.push('Merged cells');
      
      table.specialFeatures = specialFeatures;
      table.extractionNotes = generateExtractionNotes(specialFeatures);
      
      detectedTables.push(table);
    }
  }
  
  // If no tables found using structural patterns, try grid-based detection
  if (detectedTables.length === 0) {
    const gridTable = extractTableFromGrid(textPositionData);
    if (gridTable) {
      detectedTables.push(gridTable);
    }
  }
  
  return detectedTables;
}

/**
 * Identify potential table structures based on consistent line spacing and column alignment
 */
function identifyTableStructures(textPositionData: TextPositionData): Array<{startLine: number, endLine: number, columns: number[]}> {
  const { lines } = textPositionData;
  const structures: Array<{startLine: number, endLine: number, columns: number[]}> = [];
  
  // Must have at least 3 lines to form a table
  if (lines.length < 3) {
    return structures;
  }
  
  // Find lines with similar number of items (potential table rows)
  const lineCounts = lines.map(line => line.items.length);
  const avgItemCount = Math.round(
    lineCounts.reduce((sum, count) => sum + count, 0) / lineCounts.length
  );
  
  // Find potential table rows (lines with approximately consistent number of items)
  const potentialTableRows = lines
    .map((line, index) => ({ line, index }))
    .filter(({ line }) => line.items.length >= 3 && Math.abs(line.items.length - avgItemCount) <= 2);
  
  // If we have enough potential rows, try to extract a table
  if (potentialTableRows.length >= 4) {
    // Find consecutive groups of lines (tables typically have consecutive rows)
    const groups: Array<{ startIdx: number, endIdx: number, lines: typeof potentialTableRows }> = [];
    let currentGroup: typeof potentialTableRows = [];
    let prevIndex = -2;
    
    for (const { line, index } of potentialTableRows) {
      if (index === prevIndex + 1) {
        // This line is consecutive with the previous one
        currentGroup.push({ line, index });
      } else {
        // Start a new group
        if (currentGroup.length >= 3) {
          groups.push({
            startIdx: currentGroup[0].index,
            endIdx: currentGroup[currentGroup.length - 1].index,
            lines: currentGroup
          });
        }
        currentGroup = [{ line, index }];
      }
      prevIndex = index;
    }
    
    // Add the last group if it has enough lines
    if (currentGroup.length >= 3) {
      groups.push({
        startIdx: currentGroup[0].index,
        endIdx: currentGroup[currentGroup.length - 1].index,
        lines: currentGroup
      });
    }
    
    // Process each group to find consistent column patterns
    for (const group of groups) {
      const columns = extractConsistentColumns(group.lines.map(item => item.line));
      
      if (columns.length >= 2) {
        structures.push({
          startLine: group.startIdx,
          endLine: group.endIdx,
          columns
        });
      }
    }
  }
  
  return structures;
}

/**
 * Check if two sets of columns are similar in structure
 */
function areColumnsSimilar(columns1: number[], columns2: number[]): boolean {
  if (Math.abs(columns1.length - columns2.length) > 1) {
    return false;
  }
  
  const minLength = Math.min(columns1.length, columns2.length);
  let similarCount = 0;
  
  for (let i = 0; i < minLength; i++) {
    const delta = Math.abs(columns1[i] - columns2[i]);
    if (delta < 10) { // 10px tolerance
      similarCount++;
    }
  }
  
  return similarCount >= minLength * 0.7; // 70% similarity threshold
}

/**
 * Extract consistent column positions from a set of lines
 */
function extractConsistentColumns(lines: Array<{
  y: number;
  items: Array<{
    text: string;
    x: number;
    width: number;
  }>;
}>): number[] {
  if (lines.length < 2) return [];
  
  // Extract starting positions of text items in each line
  const positionSets = lines.map(line => 
    line.items.map(item => Math.round(item.x))
  );
  
  // Find the most consistent set of positions
  let bestPositions = positionSets[0];
  let maxSimilarCount = 0;
  
  for (const positions of positionSets) {
    let similarCount = 0;
    
    for (const otherPositions of positionSets) {
      if (areColumnsSimilar(positions, otherPositions)) {
        similarCount++;
      }
    }
    
    if (similarCount > maxSimilarCount) {
      maxSimilarCount = similarCount;
      bestPositions = positions;
    }
  }
  
  // Return the best positions if they're consistent across at least 70% of lines
  if (maxSimilarCount >= lines.length * 0.7) {
    return bestPositions.sort((a, b) => a - b);
  }
  
  return [];
}

/**
 * Extract table data from an identified table structure
 */
function extractTableData(
  startLine: number,
  endLine: number,
  columnPositions: number[],
  textPositionData: TextPositionData
): DetectedTable {
  const { lines } = textPositionData;
  
  // Extract headers from the first line
  const headers = extractCellsFromLine(lines[startLine], columnPositions).map(cell => cell.text);
  
  // Extract rows
  const rows: TableCell[][] = [];
  for (let i = startLine + 1; i <= endLine; i++) {
    if (i < lines.length) {
      const rowCells = extractCellsFromLine(lines[i], columnPositions);
      rows.push(rowCells);
    }
  }
  
  return {
    headers,
    rows
  };
}

/**
 * Extract cells from a line based on column positions
 */
function extractCellsFromLine(line: {
  y: number;
  items: Array<{
    text: string;
    x: number;
    width: number;
  }>;
}, columnPositions: number[]): TableCell[] {
  const cells: TableCell[] = [];
  
  // Create empty cells
  for (let i = 0; i < columnPositions.length; i++) {
    cells.push({ text: '' });
  }
  
  // Assign each text item to the closest column
  for (const item of line.items) {
    const columnIndex = findClosestColumnIndex(item.x, columnPositions);
    
    if (columnIndex >= 0 && columnIndex < cells.length) {
      // Append text to the cell (with space if not empty)
      cells[columnIndex].text = cells[columnIndex].text 
        ? cells[columnIndex].text + ' ' + item.text 
        : item.text;
    }
  }
  
  return cells;
}

/**
 * Find the closest column index for a given x position
 */
function findClosestColumnIndex(x: number, columns: number[]): number {
  let closestIndex = -1;
  let minDistance = Number.POSITIVE_INFINITY;
  
  for (let i = 0; i < columns.length; i++) {
    const distance = Math.abs(x - columns[i]);
    
    if (distance < minDistance) {
      minDistance = distance;
      closestIndex = i;
    }
  }
  
  return closestIndex;
}

/**
 * Check if the table has multi-line cells
 */
function hasMultiLineCells(rows: TableCell[][]): boolean {
  // Simple heuristic: check if any cell contains newlines
  for (const row of rows) {
    for (const cell of row) {
      if (cell.text.includes('\n')) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Check if the table has merged cells
 */
function hasMergedCells(rows: TableCell[][]): boolean {
  // In this simplified implementation, we'll infer from missing cells
  if (rows.length === 0) return false;
  
  const expectedLength = rows[0].length;
  for (const row of rows) {
    if (row.length !== expectedLength) {
      return true;
    }
    
    // Check for empty cells (potential vertical span)
    const emptyCount = row.filter(cell => cell.text.trim() === '').length;
    if (emptyCount > expectedLength / 3) { // If more than 1/3 are empty
      return true;
    }
  }
  
  return false;
}

/**
 * Infer the table type based on headers
 */
function inferTableType(headers: string[]): string {
  const headerText = headers.join(' ').toLowerCase();
  
  if (headerText.includes('date') && (
    headerText.includes('amount') || 
    headerText.includes('payment') || 
    headerText.includes('transaction')
  )) {
    return 'Financial Table';
  }
  
  if (headerText.includes('item') && (
    headerText.includes('quantity') || 
    headerText.includes('price') || 
    headerText.includes('amount')
  )) {
    return 'Invoice Table';
  }
  
  if (headerText.includes('name') && (
    headerText.includes('email') || 
    headerText.includes('phone') || 
    headerText.includes('address')
  )) {
    return 'Contact Information Table';
  }
  
  if (headerText.includes('product') || 
      headerText.includes('item') || 
      headerText.includes('description')) {
    return 'Product Table';
  }
  
  return 'Data Table';
}

/**
 * Determine the table structure (bordered, borderless, mixed)
 */
function determineTableStructure(
  textPositionData: TextPositionData, 
  startLine: number, 
  endLine: number
): 'bordered' | 'borderless' | 'mixed' {
  // This is a simplified implementation that would be enhanced with actual border detection
  // For now, we'll make a simple heuristic determination
  
  // If header text items are bold but row text items are not, it's likely borderless
  const headerItems = textPositionData.items.filter(item => 
    Math.abs(item.y - textPositionData.lines[startLine].y) < 5
  );
  
  const bodyItems = textPositionData.items.filter(item => 
    item.y > textPositionData.lines[startLine].y && 
    item.y <= textPositionData.lines[endLine].y
  );
  
  const headerBoldCount = headerItems.filter(item => item.isBold).length;
  const bodyBoldCount = bodyItems.filter(item => item.isBold).length;
  
  const headerBoldRatio = headerItems.length > 0 ? headerBoldCount / headerItems.length : 0;
  const bodyBoldRatio = bodyItems.length > 0 ? bodyBoldCount / bodyItems.length : 0;
  
  if (headerBoldRatio > 0.7 && bodyBoldRatio < 0.3) {
    return 'borderless'; // Likely using bold text instead of borders for headers
  }
  
  // Look at spacing between lines - consistent tight spacing often indicates borderless tables
  const lineSpacings: number[] = [];
  for (let i = startLine; i < endLine; i++) {
    lineSpacings.push(textPositionData.lines[i+1].y - textPositionData.lines[i].y);
  }
  
  // Calculate standard deviation of spacings
  const avgSpacing = lineSpacings.reduce((sum, spacing) => sum + spacing, 0) / lineSpacings.length;
  const spacingVariance = lineSpacings.reduce((sum, spacing) => sum + Math.pow(spacing - avgSpacing, 2), 0) / lineSpacings.length;
  const spacingStdDev = Math.sqrt(spacingVariance);
  
  if (spacingStdDev < 2) { // Very consistent spacing
    return 'bordered'; // Likely a bordered table with consistent row heights
  }
  
  return 'mixed'; // Default to mixed when uncertain
}

/**
 * Generate notes about the extraction process
 */
function generateExtractionNotes(specialFeatures: string[]): string {
  if (specialFeatures.includes('Merged cells')) {
    return 'Table contains merged cells. Cell relationships reconstructed based on position analysis.';
  }
  
  if (specialFeatures.includes('Multi-line cells')) {
    return 'Table contains multi-line cells. Content combined based on vertical alignment.';
  }
  
  return 'Table extracted with standard processing.';
}

/**
 * Extract a table from grid-based detection when structural detection fails
 */
function extractTableFromGrid(textPositionData: TextPositionData): DetectedTable | null {
  const { lines } = textPositionData;
  
  // Only proceed if we have at least 5 lines
  if (lines.length < 5) {
    return null;
  }
  
  // Calculate average number of text items per line
  const avgItemCount = lines.reduce((sum, line) => sum + line.items.length, 0) / lines.length;
  
  // Find lines that have approximately the average number of items
  const potentialTableRows = lines
    .map((line, index) => ({ line, index }))
    .filter(({ line }) => line.items.length >= 3 && Math.abs(line.items.length - avgItemCount) <= 2);
  
  // If we have enough potential rows, try to extract a table
  if (potentialTableRows.length >= 4) {
    // Find consecutive groups of lines (tables typically have consecutive rows)
    const groups: Array<{ startIdx: number, endIdx: number, lines: typeof potentialTableRows }> = [];
    let currentGroup: typeof potentialTableRows = [];
    let prevIndex = -2;
    
    for (const { line, index } of potentialTableRows) {
      if (index === prevIndex + 1) {
        // This line is consecutive with the previous one
        currentGroup.push({ line, index });
      } else {
        // Start a new group
        if (currentGroup.length >= 3) {
          groups.push({
            startIdx: currentGroup[0].index,
            endIdx: currentGroup[currentGroup.length - 1].index,
            lines: currentGroup
          });
        }
        currentGroup = [{ line, index }];
      }
      prevIndex = index;
    }
    
    // Add the last group if it has enough lines
    if (currentGroup.length >= 3) {
      groups.push({
        startIdx: currentGroup[0].index,
        endIdx: currentGroup[currentGroup.length - 1].index,
        lines: currentGroup
      });
    }
    
    if (groups.length > 0) {
      // Use the largest group
      let largestGroup = groups[0];
      for (const group of groups) {
        if (group.lines.length > largestGroup.lines.length) {
          largestGroup = group;
        }
      }
      
      // Extract approximate column positions
      const columnPositions: number[] = [];
      const positionCounts: { [key: string]: number } = {};
      
      for (const rowData of largestGroup.lines) {
        for (const item of rowData.line.items) {
          const roundedX = Math.round(item.x / 10) * 10; // Round to nearest 10px
          const key = roundedX.toString();
          
          if (!(key in positionCounts)) {
            positionCounts[key] = 0;
          }
          
          positionCounts[key]++;
        }
      }
      
      // Find positions that appear in at least 30% of lines
      const threshold = Math.floor(largestGroup.lines.length * 0.3);
      for (const [pos, count] of Object.entries(positionCounts)) {
        if (count >= threshold) {
          columnPositions.push(parseInt(pos));
        }
      }
      
      // Sort column positions
      columnPositions.sort((a, b) => a - b);
      
      // If we have enough columns, create a table
      if (columnPositions.length >= 3) {
        // Extract the table
        const { startIdx, endIdx } = largestGroup;
        const headers = extractCellsFromLine(lines[startIdx], columnPositions).map(cell => cell.text);
        
        const rows: TableCell[][] = [];
        for (let i = startIdx + 1; i <= endIdx; i++) {
          const row = extractCellsFromLine(lines[i], columnPositions);
          rows.push(row);
        }
        
        return {
          headers,
          rows,
          type: 'Generic Table',
          structure: 'mixed',
          specialFeatures: ['Grid-based detection'],
          extractionNotes: 'Table detected using grid-based analysis. Structure was inferred from text positioning.'
        };
      }
    }
  }
  
  return null;
}