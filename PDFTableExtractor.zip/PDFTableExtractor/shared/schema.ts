import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const pdfDocuments = pgTable("pdf_documents", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  filesize: integer("filesize").notNull(),
  uploadDate: timestamp("upload_date").defaultNow().notNull(),
  userId: integer("user_id").references(() => users.id),
});

export const insertPdfDocumentSchema = createInsertSchema(pdfDocuments).pick({
  filename: true,
  filesize: true,
  userId: true,
});

export type InsertPdfDocument = z.infer<typeof insertPdfDocumentSchema>;
export type PdfDocument = typeof pdfDocuments.$inferSelect;

export const extractedTables = pgTable("extracted_tables", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").references(() => pdfDocuments.id).notNull(),
  tableIndex: integer("table_index").notNull(),
  pageNumber: integer("page_number").notNull(),
  tableData: jsonb("table_data").notNull(),
  tableInfo: jsonb("table_info").notNull(),
  extractionDate: timestamp("extraction_date").defaultNow().notNull(),
});

export const insertExtractedTableSchema = createInsertSchema(extractedTables).pick({
  documentId: true,
  tableIndex: true,
  pageNumber: true,
  tableData: true,
  tableInfo: true,
});

export type InsertExtractedTable = z.infer<typeof insertExtractedTableSchema>;
export type ExtractedTable = typeof extractedTables.$inferSelect;

// Table detection API request/response types
export interface TableCell {
  text: string;
  rowSpan?: number;
  colSpan?: number;
}

export interface TableData {
  headers: string[];
  rows: TableCell[][];
}

export interface TableInfo {
  type: string;
  pageNumber: number;
  rowCount: number;
  columnCount: number;
  structure: 'bordered' | 'borderless' | 'mixed';
  specialFeatures?: string[];
  detectionMethod: string;
  extractionNotes?: string;
}

export interface ExtractedTableData {
  tableIndex: number;
  data: TableData;
  info: TableInfo;
}

export interface PdfExtractionResponse {
  documentId: number;
  filename: string;
  filesize: number;
  uploadDate: string;
  tables: ExtractedTableData[];
}
